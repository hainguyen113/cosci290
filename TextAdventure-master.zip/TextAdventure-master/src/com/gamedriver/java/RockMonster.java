package com.gamedriver.java;

public class RockMonster extends Enemy{
    public RockMonster(){
        super("Rock Monster", 10, 7, 7);
    }
}
