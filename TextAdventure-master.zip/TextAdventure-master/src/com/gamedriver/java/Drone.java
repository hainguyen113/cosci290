package com.gamedriver.java;

public class Drone extends Enemy {
    public Drone(){
        super("Drone", 25, 25, 25);
    }
}
