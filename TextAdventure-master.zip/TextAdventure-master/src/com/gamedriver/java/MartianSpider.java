package com.gamedriver.java;

public class MartianSpider extends Enemy {
    public MartianSpider() {
        super("Martian Spider", 7, 3, 2);
    }

    public MartianSpider(int health) {
        super("Martian Spider", health, 3, 2);
    }
}
