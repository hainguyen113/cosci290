package com.gamedriver.java;

public class BlackSlime extends Enemy {
    public BlackSlime(){
        super("Black Slime", 25, 25, 15);
    }
}
