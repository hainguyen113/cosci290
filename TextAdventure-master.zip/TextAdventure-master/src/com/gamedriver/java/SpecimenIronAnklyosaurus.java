package com.gamedriver.java;

public class SpecimenIronAnklyosaurus extends Enemy {
    public SpecimenIronAnklyosaurus() {
        super("Specimen 17X: Iron Anklyosaurus", 50, 15, 20);
    }
}
