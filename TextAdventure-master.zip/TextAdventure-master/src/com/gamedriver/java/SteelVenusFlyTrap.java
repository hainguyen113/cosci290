package com.gamedriver.java;

public class SteelVenusFlyTrap extends Enemy {
    public SteelVenusFlyTrap(){
        super("Steel Venus Fly Trap", 7, 2, 5);
    }
}
