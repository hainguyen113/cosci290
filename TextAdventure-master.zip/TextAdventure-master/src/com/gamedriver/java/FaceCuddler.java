package com.gamedriver.java;

public class FaceCuddler extends Enemy {
    public FaceCuddler() {
        super("Face-Cuddler", 5, 7, 15);
    }
}
