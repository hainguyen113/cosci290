package com.gamedriver.java;

public class NoEnemy extends Enemy {
    public NoEnemy() {
        super("There is no immminent threat in the room", 0, 0, 0);
    }
}
