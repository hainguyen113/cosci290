package com.gamedriver.java;

public class GameMap {

    int[][] grid = new int[4][4];
    //create a 4x4 grid

    //set our starting coordinates


    }


