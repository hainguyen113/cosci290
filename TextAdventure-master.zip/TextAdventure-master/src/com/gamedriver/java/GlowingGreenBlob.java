package com.gamedriver.java;

public class GlowingGreenBlob extends Enemy {
    public GlowingGreenBlob(){
        super("Glowing Green Blob", 30, 5, 5);
    }
}
