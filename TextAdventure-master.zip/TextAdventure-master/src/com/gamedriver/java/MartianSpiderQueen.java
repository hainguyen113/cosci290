package com.gamedriver.java;

public class MartianSpiderQueen extends Enemy {
    public MartianSpiderQueen(){
        super("Martian Spider Queen", 35, 20, 20);
    }
}
