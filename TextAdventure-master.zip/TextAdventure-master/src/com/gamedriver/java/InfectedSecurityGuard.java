package com.gamedriver.java;

public class InfectedSecurityGuard extends Enemy{
    public InfectedSecurityGuard() {
        super("Infected Security Guard", 15, 10, 10);
    }
}
